<?php

return [
    'title' => 'Sign In',
    'email' => 'Email Address',
    'email_placeholder' => 'Enter your email',
    'password' => 'Password',
    'password_placeholder' => 'Enter your password',
    'signin' => 'Sign In',
    'signup' => 'Sign Up',
    'no_account' => 'No account yet?',
    'error_title' => 'Oops! Please check the errors below:',
];
