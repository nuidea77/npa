<?php
return [
    'manage_verification' => 'Харилцагчийн баталгаажуулалтын хүсэлтүүдийг удирдах',
    'customer_verification_requests' => 'Харилцагчийн баталгаажуулалтын хүсэлтүүд',
    'all' => 'Бүгд',
    'pending' => 'Хүлээгдэж байна',
    'approved' => 'Зөвшөөрөгдсөн',
    'rejected' => 'Татгалзсан',
    'no_requests_found' => 'Сонгосон төлөвт тохирох хүсэлт олдсонгүй.',
    'id' => 'Дугаар',
    'customer_name' => 'Харилцагчийн нэр',
    'email' => 'Имэйл',
    'phone' => 'Утас',
    'status' => 'Төлөв',
    'actions' => 'Үйлдэл',
    'approve' => 'Зөвшөөрөх',
    'reject' => 'Татгалзах',
    'no_action_available' => 'Үйлдэл хийх боломжгүй'
];
