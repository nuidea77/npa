<?php

return [
    'title' => 'Нэвтрэх',
    'email' => 'И-мэйл хаяг',
    'email_placeholder' => 'И-мэйлээ оруулна уу',
    'password' => 'Нууц үг',
    'password_placeholder' => 'Нууц үгээ оруулна уу',
    'signin' => 'Нэвтрэх',
    'signup' => 'Бүртгүүлэх',
    'no_account' => 'Бүртгэл байхгүй юу?',
    'error_title' => 'Алдаа гарлаа! Доорх алдааг шалгана уу:',
];
