<?php

return [

    'failed' => 'These credentials do not match our records.',

];
