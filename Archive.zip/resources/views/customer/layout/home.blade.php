<div class="body-wrapper-inner">
    @yield('content')
</div>
