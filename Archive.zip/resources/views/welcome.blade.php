@extends('layout.main')

@section('content')

@include('layout.home')

@stop


