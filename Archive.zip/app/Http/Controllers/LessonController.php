<?php



namespace App\Http\Controllers;

use App\Models\Customer;
use Illuminate\Http\Request;
use App\Models\Lesson;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class LessonController extends Controller
{
    public function view($id)
    {
        // Fetch the lesson with translations using only the necessary fields for optimization
        $lesson = Lesson::with('translations')->findOrFail($id);

        // Current time
        $now = now();

        // Check if lesson has started and if it has finished
        $startedNotYet = $lesson->started_at && $now->lt($lesson->started_at);
        $finishedPassed = $lesson->finished_at && $now->gt($lesson->finished_at);

        // Check if user is authenticated
        $isAuthenticated = Auth::guard('customer')->check();


        // Determine modal status and message based on conditions
        $modalStatus = $this->determineModalStatus($lesson, $isAuthenticated, $startedNotYet, $finishedPassed);

        return view('lessons.view' , [
            'lesson' => $lesson,
            'startedNotYet' => $startedNotYet,
            'finishedPassed' => $finishedPassed,
            'isAuthenticated' => $isAuthenticated,
            'modalStatus' => $modalStatus,
        ]);
    }

    private function determineModalStatus($lesson, $isAuthenticated, $startedNotYet, $finishedPassed)
    {
        // If the lesson requires authentication (type 1)
        if ($lesson->type == 1 && !$isAuthenticated) {
        return $this->modalResponse('login', __('texts.login-required'));
    }

    if ($startedNotYet) {
        return $this->modalResponse('not_started', __('texts.lesson-not-started'), $lesson->started_at);
    }

    if ($finishedPassed) {
        return $this->modalResponse('finished', __('texts.lesson-ended'), $lesson->finished_at);
    }

        // No modal
        return $this->modalResponse();
    }

    /**
     * Generate a modal response.
     *
     * @param string|null $type
     * @param string|null $message
     * @param string|null $time
     * @return array
     */
    private function modalResponse($type = null, $message = null, $time = null)
    {
        return [
            'show' => $type !== null,
            'type' => $type,
            'message' => $message,
            'startTime' => $time ? Carbon::parse($time)->format('Y-m-d H:i:s') : null,
            'endTime' => $time ? Carbon::parse($time)->format('Y-m-d H:i:s') : null,
        ];
    }
}
