<?php $__env->startSection('page_title', __('messages.manage_verification')); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1 class="text-center mb-4"><?php echo e(__('messages.customer_verification_requests')); ?></h1>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <!-- Filter by Status -->
    <form method="GET" action="<?php echo e(route('admin.custom.page')); ?>" class="mb-3">
        <div class="row">
            <div class="col-md-4">
                <select name="status" class="form-select" onchange="this.form.submit()">
                    <option value="all" <?php echo e(request('status') === 'all' || request('status') === null ? 'selected' : ''); ?>>
                        <?php echo e(__('messages.all')); ?>

                    </option>
                    <option value="null" <?php echo e(request('status') === 'null' ? 'selected' : ''); ?>>
                        <?php echo e(__('messages.pending')); ?>

                    </option>
                    <option value="1" <?php echo e(request('status') == '1' ? 'selected' : ''); ?>>
                        <?php echo e(__('messages.approved')); ?>

                    </option>
                    <option value="0" <?php echo e(request('status') == '0' ? 'selected' : ''); ?>>
                        <?php echo e(__('messages.rejected')); ?>

                    </option>
                </select>
            </div>
        </div>
    </form>

    <?php if($pendingRequests->isEmpty()): ?>
        <p class="text-center"><?php echo e(__('messages.no_requests_found')); ?></p>
    <?php else: ?>
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th><?php echo e(__('messages.id')); ?></th>
                    <th><?php echo e(__('messages.customer_name')); ?></th>
                    <th><?php echo e(__('messages.email')); ?></th>
                    <th><?php echo e(__('messages.phone')); ?></th>
                    <th><?php echo e(__('messages.status')); ?></th>
                    <th><?php echo e(__('messages.actions')); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $pendingRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($customer->id); ?></td>
                        <td><?php echo e($customer->firstname); ?> <?php echo e($customer->lastname); ?></td>
                        <td><?php echo e($customer->email); ?></td>
                        <td><?php echo e($customer->phone); ?></td>
                        <td>
                            <?php if(is_null($customer->verify_status)): ?>
                                <span class="badge bg-warning"><?php echo e(__('messages.pending')); ?></span>
                            <?php elseif($customer->verify_status === 1): ?>
                                <span class="badge bg-success"><?php echo e(__('messages.approved')); ?></span>
                            <?php elseif($customer->verify_status === 0): ?>
                                <span class="badge bg-danger"><?php echo e(__('messages.rejected')); ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if(is_null($customer->verify_status)): ?>
                                <a href="<?php echo e(route('admin.customer.verify', ['id' => $customer->id, 'status' => 1])); ?>"
                                   class="btn btn-success btn-sm"><?php echo e(__('messages.approve')); ?></a>
                                <a href="<?php echo e(route('admin.customer.verify', ['id' => $customer->id, 'status' => 0])); ?>"
                                   class="btn btn-danger btn-sm"><?php echo e(__('messages.reject')); ?></a>
                            <?php elseif($customer->verify_status === 0): ?>
                                <a href="<?php echo e(route('admin.customer.verify', ['id' => $customer->id, 'status' => 1])); ?>"
                                   class="btn btn-success btn-sm"><?php echo e(__('messages.approve')); ?></a>
                            <?php else: ?>
                                <span class="text-muted"><?php echo e(__('messages.no_action_available')); ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/a123/Desktop/npa/resources/views/admin/custom-page.blade.php ENDPATH**/ ?>