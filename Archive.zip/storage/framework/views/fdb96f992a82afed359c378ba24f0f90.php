<?php $__env->startSection('content'); ?>
    <div class="container ">
        <div class="row">
            <div class="col-lg-12">

                <div class=" <?php echo e($modalStatus['show'] ? 'lesson-blurred' : ''); ?>">
                    
                    <div class="lesson-content">

                        <div style="background-image: url(<?php echo e(Voyager::image($lesson->cover)); ?>); height:400px; background-repeat:no-repeat; background-size:cover; background-position:center;" ></div>
                        <h1 class="text-center py-3"><?php echo e($lesson->title); ?></h1>


                        
                        <?php if(!$modalStatus['show']): ?>
                            
                            <div class="lesson-media">
                                
                                <?php echo $lesson->body; ?>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="lesson-container">
                    
                    <?php if($modalStatus): ?>
                        <div id="lesson-access-modal" class="modal fade"  data-bs-backdrop="static" data-bs-keyboard="false">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header">
                                            <a href="<?php echo e(url()->previous()); ?>" class="float-start program-date text-decoration-none">
    <i class="bi bi-chevron-left"></i> <?php echo app('translator')->get('texts.back'); ?>
</a>
                                    </div>

                                    <div class="modal-body">

                                       <?php switch($modalStatus['type']):
    case ('login'): ?>
        <h2><?php echo app('translator')->get('texts.login-required'); ?></h2>
        <p><?php echo e($modalStatus['message']); ?></p>
        <a href="<?php echo e(route('customer.signin')); ?>" class="btn btn-primary"><?php echo app('translator')->get('texts.login'); ?></a>
        <?php break; ?>

    <?php case ('not_started'): ?>
        <h2><?php echo app('translator')->get('texts.lesson-not-started'); ?></h2>
        <p><?php echo e($modalStatus['message']); ?></p>
        <p><strong><?php echo app('translator')->get('texts.start-time'); ?>:</strong> <?php echo e($modalStatus['startTime']); ?></p>
        <?php break; ?>

    <?php case ('finished'): ?>
        <h2><?php echo app('translator')->get('texts.lesson-ended'); ?></h2>
        <p><?php echo e($modalStatus['message']); ?></p>
        <p><strong><?php echo app('translator')->get('texts.end-time'); ?>:</strong> <?php echo e($modalStatus['endTime']); ?></p>
        <?php break; ?>
<?php endswitch; ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
    // Initialize Bootstrap modal if modalStatus['show'] is true
    const modalStatusShow = <?php echo e($modalStatus['show'] ? 'true' : 'false'); ?>;

    if (modalStatusShow) {
        const modal = new bootstrap.Modal(document.getElementById('lesson-access-modal'));
        modal.show(); // Show the modal
    }
});
</script>


<?php echo $__env->make('customer.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/a123/Desktop/npa/resources/views/customer/lesson.blade.php ENDPATH**/ ?>