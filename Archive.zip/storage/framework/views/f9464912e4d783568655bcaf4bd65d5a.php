<?php $__env->startSection('content'); ?>
    <div class="container ">
        <div class="row">
            <div class="col-lg-12">

                <div class="<?php echo e($modalStatus['show'] ? 'lesson-blurred' : ''); ?>">
                    
                    <div class="lesson-content">
                        <h1><?php echo e($lesson->title); ?></h1>
                        <img src="<?php echo e(Voyager::image($lesson->cover)); ?>" alt="">


                        
                        <?php if(!$modalStatus['show']): ?>
                            
                            <div class="lesson-media">
                                
                                <?php echo $lesson->body; ?>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="lesson-container">
                    
                    <?php if($modalStatus): ?>
                        <div id="lesson-access-modal" class="modal fade"  data-bs-backdrop="static" data-bs-keyboard="false">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">

                                    <div class="modal-body">
                                        <?php switch($modalStatus['type']):
                                            case ('login'): ?>
                                                <h2>Нэвтрэх шаардлага</h2>
                                                <p><?php echo e($modalStatus['message']); ?></p>
                                                <a href="<?php echo e(route('customer.signin')); ?>" class="btn btn-primary">Нэвтрэх</a>
                                            <?php break; ?>

                                            <?php case ('not_started'): ?>
                                                <h2>Хичээл эхлээгүй</h2>
                                                <p><?php echo e($modalStatus['message']); ?></p>
                                                <p>Эхлэх хугацаа: <?php echo e($modalStatus['startTime']); ?></p>
                                            <?php break; ?>

                                            <?php case ('finished'): ?>
                                                <h2>Хичээл дууссан</h2>
                                                <p><?php echo e($modalStatus['message']); ?></p>
                                                <p>Дуусах хугацаа: <?php echo e($modalStatus['endTime']); ?></p>
                                            <?php break; ?>
                                        <?php endswitch; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
    // Initialize Bootstrap modal if modalStatus['show'] is true
    const modalStatusShow = <?php echo e($modalStatus['show'] ? 'true' : 'false'); ?>;

    if (modalStatusShow) {
        const modal = new bootstrap.Modal(document.getElementById('lesson-access-modal'));
        modal.show(); // Show the modal
    }
});
</script>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/a123/Desktop/npa/resources/views/lessons/view.blade.php ENDPATH**/ ?>