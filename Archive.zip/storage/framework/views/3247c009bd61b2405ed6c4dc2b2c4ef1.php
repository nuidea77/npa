<nav class="navbar navbar-default navbar-fixed-top navbar-top">
    <div class="container-fluid">
        <div class="navbar-header">
            <button class="hamburger btn-link">
                <span class="hamburger-inner"></span>
            </button>
            <?php $__env->startSection('breadcrumbs'); ?>
            <ol class="breadcrumb hidden-xs">
                <?php
                    $segments = array_filter(explode('/', str_replace(route('voyager.dashboard'), '', Request::url())));
                    $url = route('voyager.dashboard');
                ?>
                <?php if(count($segments) == 0): ?>
                    <li class="active"><i class="voyager-boat"></i> <?php echo e(__('voyager::generic.dashboard')); ?></li>
                <?php else: ?>
                    <li class="active">
                        <a href="<?php echo e(route('voyager.dashboard')); ?>"><i class="voyager-boat"></i> <?php echo e(__('voyager::generic.dashboard')); ?></a>
                    </li>
                    <?php $__currentLoopData = $segments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $segment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $url .= '/'.$segment; ?>
                        <?php if($loop->last): ?>
                            <li><?php echo e(ucfirst(urldecode($segment))); ?></li>
                        <?php else: ?>
                            <li><a href="<?php echo e($url); ?>"><?php echo e(ucfirst(urldecode($segment))); ?></a></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </ol>
            <?php echo $__env->yieldSection(); ?>
        </div>

        <ul class="nav navbar-nav navbar-right">
            
            <li class="dropdown" style="position:relative;">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="voyager-bell"></i>
                    <?php $unreadCount = auth()->user()->unreadNotifications->count(); ?>
                    <?php if($unreadCount): ?>
                        <span class="badge badge-primary"><?php echo e($unreadCount); ?></span>
                    <?php endif; ?>
                </a>
                <ul class="dropdown-menu notifications dropdown-menu-animated" style="min-width:320px; max-height:350px; overflow-y:auto; padding:5px;">
                    <?php $__empty_1 = true; $__currentLoopData = auth()->user()->unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li style="margin-bottom:5px;">
                            <a href="<?php echo e($notification->data['url'] ?? '#'); ?>"
                               class="notification-link"
                               data-id="<?php echo e($notification->id); ?>"
                               style="display:block; padding:10px; border-radius:6px; background-color: <?php echo e($notification->read_at ? '#fff' : '#22a7f0'); ?>; color: <?php echo e($notification->read_at ? '#333' : '#fff'); ?>;">
                                <strong style="display:block; font-size:0.95rem;"><?php echo e($notification->data['title'] ?? 'Мэдэгдэл'); ?></strong>
                                <p style="margin:2px 0 0; font-size:12px; line-height:1.3;"><?php echo e($notification->data['message'] ?? ''); ?></p>
                                <small style="font-size:10px; opacity:0.7; display:block;"><?php echo e($notification->created_at->diffForHumans()); ?></small>
                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="text-center text-muted" style="padding:10px;">Мэдэгдэл алга</li>
                    <?php endif; ?>
                    <li class="text-center" style="padding:5px; border-top:1px solid #eee;">
                        <a href="<?php echo e(route('voyager.notifications.index')); ?>">Бүгдийг харах</a>
                    </li>
                </ul>
            </li>

            
            <li class="dropdown profile">
                <a href="#" class="dropdown-toggle text-right" data-toggle="dropdown">
                    <img src="<?php echo e($user_avatar); ?>" class="profile-img"> <span class="caret"></span>
                </a>
                <ul class="dropdown-menu dropdown-menu-animated">
                    <li class="profile-img text-center">
                        <img src="<?php echo e($user_avatar); ?>" class="profile-img" style="width:60px; height:60px; border-radius:50%;">
                        <div class="profile-body">
                            <h5><?php echo e(Auth::user()->name); ?></h5>
                            <h6><?php echo e(Auth::user()->email); ?></h6>
                        </div>
                    </li>
                    <li class="divider"></li>
                    <?php $nav_items = config('voyager.dashboard.navbar_items'); ?>
                    <?php if(is_array($nav_items) && !empty($nav_items)): ?>
                        <?php $__currentLoopData = $nav_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li <?php echo isset($item['classes']) ? 'class="'.$item['classes'].'"' : ''; ?>>
                                <?php if(isset($item['route']) && $item['route']=='voyager.logout'): ?>
                                    <form action="<?php echo e(route('voyager.logout')); ?>" method="POST" style="margin:0;">
                                        <?php echo e(csrf_field()); ?>

                                        <button type="submit" class="btn btn-block btn-danger">
                                            <?php if(!empty($item['icon_class'])): ?> <i class="<?php echo e($item['icon_class']); ?>"></i> <?php endif; ?>
                                            <?php echo e(__($name)); ?>

                                        </button>
                                    </form>
                                <?php else: ?>
                                    <a href="<?php echo e(isset($item['route']) && Route::has($item['route']) ? route($item['route']) : '#'); ?>">
                                        <?php if(!empty($item['icon_class'])): ?> <i class="<?php echo e($item['icon_class']); ?>"></i> <?php endif; ?>
                                        <?php echo e(__($name)); ?>

                                    </a>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </ul>
            </li>
        </ul>
    </div>
</nav>

<?php $__env->startSection('styles'); ?>
<style>
    /* Hover & colors */
    .notifications .notification-link:hover {
        background-color: #286090 !important;
        color: #fff !important;
    }

    .badge-primary {
        background-color: #337ab7;
        font-size: 0.75em;
    }

    /* Scrollbar */






</style>
<?php $__env->stopSection(); ?>

<script>
$(document).ready(function(){
    $('.notification-link').click(function(e){
        e.preventDefault();
        let link = $(this).attr('href');
        let id = $(this).data('id');

        if(id){
            $.post('<?php echo e(route('notifications.read')); ?>', {
                _token:'<?php echo e(csrf_token()); ?>', id:id
            }, function(){ window.location.href = link; });
        } else { window.location.href = link; }
    });
});
</script>
<?php /**PATH /Users/a123/Desktop/npa/vendor/tcg/voyager/src/../resources/views/dashboard/navbar.blade.php ENDPATH**/ ?>