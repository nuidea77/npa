<?php $__env->startSection('content'); ?>
<div class="container-fluid">

</div>
<div class="container">
    <div class="row py-5">
        <div class="col-lg-12">
              <div class="row pb-5">
        <div class="col-md-12 pt-5 ">
             <a href="<?php echo e(url()->previous()); ?>" class="float-start program-date text-decoration-none">
    <i class="bi bi-chevron-left"></i> <?php echo app('translator')->get('texts.back'); ?>
</a>
            <h4 class="text-center  text-uppercase fw-semibold"><?php echo app('translator')->get('texts.faq'); ?></h4>
        </div>
    </div>
            <div class="accordion" id="accordionExample">
                <?php if(isset($faqs)): ?>
                <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="heading-<?php echo e($data->id); ?>">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-<?php echo e($data->id); ?>" aria-expanded="<?php echo e($data->id); ?>" aria-controls="collapse-<?php echo e($data->id); ?>">
                                <?php echo e($data->question); ?>

                            </button>
                        </h2>
                        <div id="collapse-<?php echo e($data->id); ?>" class="accordion-collapse collapse-<?php echo e($data->id); ?> " aria-labelledby="heading-<?php echo e($data->id); ?>" data-bs-parent="#accordionExample">
                            <div class="accordion-body">
                                <p><?php echo e($data->answer); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/a123/Desktop/npa/resources/views/pages/faq.blade.php ENDPATH**/ ?>