<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title><?php echo app('translator')->get('signin.title'); ?></title>

  <link rel="shortcut icon" href="<?php echo e(asset('assets/img/favicon.png')); ?>">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo e(asset('assets/admin/assets/css/vendor.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/admin/assets/css/theme.min.css')); ?>">
</head>

<body class="d-flex align-items-center min-vh-100">

<main id="content" role="main" class="main pt-0">
  <div class="container-fluid px-3">
    <div class="row">
      <!-- Background image side -->
      <div class="col-lg-8 d-none d-lg-flex justify-content-center align-items-center bg-light"
           style="background: url('<?php echo e(asset('assets/img/about-cover.jpg')); ?>') no-repeat center center; background-size: cover;">
      </div>

      <!-- Form side -->
      <div class="col-lg-4 d-flex justify-content-center align-items-center min-vh-lg-100">
        <div class="w-100" style="max-width: 25rem;">

          
          <?php if($errors->any()): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
              <strong><?php echo app('translator')->get('signin.error_title'); ?></strong>
              <ul class="mt-2 mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
          <?php endif; ?>

          
          <form action="<?php echo e(route('customer.signin.submit')); ?>" method="POST">
              <?php echo csrf_field(); ?>

              <div class="mb-3">
                  <label for="email" class="form-label"><?php echo app('translator')->get('signin.email'); ?></label>
                  <input type="email" name="email" id="email" class="form-control" placeholder="<?php echo app('translator')->get('signin.email_placeholder'); ?>" value="<?php echo e(old('email')); ?>" required>
              </div>

              <div class="mb-3">
                  <label for="password" class="form-label"><?php echo app('translator')->get('signin.password'); ?></label>
                  <input type="password" name="password" id="password" class="form-control" placeholder="<?php echo app('translator')->get('signin.password_placeholder'); ?>" required>
              </div>

              <button type="submit" class="btn btn-primary w-100"><?php echo app('translator')->get('signin.signin'); ?></button>

          </form>

          
          <div class="text-center mt-3">
              
          </div>
          <div class="text-center mt-2">
              <p><?php echo app('translator')->get('signin.no_account'); ?> <a href="<?php echo e(route('customer.register')); ?>" class="text-decoration-none"><?php echo app('translator')->get('signin.signup'); ?></a></p>
          </div>

        </div>
      </div>

    </div>
  </div>
</main>

<script src="<?php echo e(asset('assets/admin/assets/js/vendor.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/assets/js/theme.min.js')); ?>"></script>

</body>
</html>
<?php /**PATH /Users/a123/Desktop/npa/resources/views/customer/signin.blade.php ENDPATH**/ ?>