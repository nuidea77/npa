<footer class="app-footer">
    <div class="site-footer-right">
        <?php if(rand(1,100) == 100): ?>
            <i class="voyager-rum-1"></i> <?php echo e(__('voyager::theme.footer_copyright2')); ?>

        <?php else: ?>
            <?php echo __('voyager::theme.footer_copyright'); ?> <a href="http://thecontrolgroup.com" target="_blank">The Control Group</a>
        <?php endif; ?>
        <?php $version = Voyager::getVersion(); ?>
        <?php if(!empty($version)): ?>
            - <?php echo e($version); ?>

        <?php endif; ?>
        <li>
    <a href="<?php echo e(route('voyager.customers.index')); ?>">
        <i class="voyager-bell"></i>
        <span>Мэдэгдэл</span>
        <?php if(isset($adminNotifications) && $adminNotifications->count() > 0): ?>
            <span class="badge badge-danger"><?php echo e($adminNotifications->count()); ?></span>
        <?php endif; ?>
    </a>
</li>

    </div>
</footer>
<?php /**PATH /Users/a123/Desktop/npa/vendor/tcg/voyager/resources/views/partials/app-footer.blade.php ENDPATH**/ ?>