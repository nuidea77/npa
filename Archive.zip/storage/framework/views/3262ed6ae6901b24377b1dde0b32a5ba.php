<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
          <div class="row py-5">
            <div class="col-lg-12">
               <a href="<?php echo e(url()->previous()); ?>" class="float-start program-date text-decoration-none">
    <i class="bi bi-chevron-left"></i> <?php echo app('translator')->get('texts.back'); ?>
</a>
                <h1 class="text-center fw-bold program-title"><?php echo app('translator')->get('customer.edit_info'); ?></h1>
            </div>
        </div>


        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('customer.update')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="avatar" class="form-label"><?php echo app('translator')->get('customer.upload_avatar'); ?></label>
                <?php if($customer->avatar): ?>
                    <div class="mb-2">
                        <img src="<?php echo e(asset('storage/' . $customer->avatar)); ?>" alt="<?php echo app('translator')->get('customer.current_avatar'); ?>" class="rounded-circle" width="80" height="80">
                    </div>
                <?php endif; ?>
                <input type="file" name="avatar" id="avatar" class="form-control">
                <small class="text-muted"><?php echo app('translator')->get('customer.keep_avatar'); ?></small>
            </div>
            <div class="mb-3">
                <label for="firstname" class="form-label"><?php echo app('translator')->get('customer.firstname'); ?></label>
                <input type="text" name="firstname" id="firstname" class="form-control" value="<?php echo e($customer->firstname); ?>" required>
            </div>
            <div class="mb-3">
                <label for="lastname" class="form-label"><?php echo app('translator')->get('customer.lastname'); ?></label>
                <input type="text" name="lastname" id="lastname" class="form-control" value="<?php echo e($customer->lastname); ?>" required>
            </div>
            <div class="mb-3">
                <label for="sex" class="form-label"><?php echo app('translator')->get('customer.gender'); ?></label>
                <select name="sex" id="sex" class="form-select" required>
                    <option value="1" <?php echo e($customer->sex === 'male' ? 'selected' : ''); ?>><?php echo app('translator')->get('customer.male'); ?></option>
                    <option value="2" <?php echo e($customer->sex === 'female' ? 'selected' : ''); ?>><?php echo app('translator')->get('customer.female'); ?></option>
                </select>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label"><?php echo app('translator')->get('customer.email'); ?></label>
                <input type="email" name="email" id="email" class="form-control" value="<?php echo e($customer->email); ?>" required>
            </div>
            <div class="mb-3">
                <label for="phone" class="form-label"><?php echo app('translator')->get('customer.phone'); ?></label>
                <input type="text" name="phone" id="phone" class="form-control" value="<?php echo e($customer->phone); ?>" required>
            </div>
            <div class="mb-3">
                <label for="hz" class="form-label"><?php echo app('translator')->get('register.protected_area'); ?></label>
                <select name="hz" id="hz" class="form-select" required>
                    <option value="" disabled selected><?php echo app('translator')->get('register.select_protected_area'); ?></option>
                    <option value="1" <?php echo e($customer->hz == 1 ? 'selected' : ''); ?>><?php echo app('translator')->get('register.tarvagatai_nuru'); ?></option>
                    <option value="2" <?php echo e($customer->hz == 2 ? 'selected' : ''); ?>><?php echo app('translator')->get('register.orkhon_khondii'); ?></option>
                    <option value="3" <?php echo e($customer->hz == 3 ? 'selected' : ''); ?>><?php echo app('translator')->get('register.munkhkhairkhan'); ?></option>
                    <option value="4" <?php echo e($customer->hz == 4 ? 'selected' : ''); ?>><?php echo app('translator')->get('register.ikh_bogd_uul'); ?></option>
                    <option value="5" <?php echo e($customer->hz == 5 ? 'selected' : ''); ?>><?php echo app('translator')->get('register.myangan_ugalzat'); ?></option>
                    <option value="6" <?php echo e($customer->hz == 6 ? 'selected' : ''); ?>><?php echo app('translator')->get('register.nomrog'); ?></option>
                    <option value="7" <?php echo e($customer->hz == 7 ? 'selected' : ''); ?>><?php echo app('translator')->get('register.khar_us_nuur'); ?></option>
                    <option value="8" <?php echo e($customer->hz == 8 ? 'selected' : ''); ?>><?php echo app('translator')->get('register.achit_nuur'); ?></option>
                    <option value="9" <?php echo e($customer->hz == 9 ? 'selected' : ''); ?>><?php echo app('translator')->get('register.otgontenger'); ?></option>
                    <option value="10" <?php echo e($customer->hz == 10 ? 'selected' : ''); ?>><?php echo app('translator')->get('register.bogdkhan_uul'); ?></option>
                    <option value="11" <?php echo e($customer->hz == 11 ? 'selected' : ''); ?>><?php echo app('translator')->get('register.ulaan_taiga'); ?></option>
                    <option value="12" <?php echo e($customer->hz == 12 ? 'selected' : ''); ?>><?php echo app('translator')->get('register.dornod_mongol'); ?></option>
                </select>
            </div>
            <div class="mb-3">
                <label for="position" class="form-label"><?php echo app('translator')->get('register.position'); ?></label>
                <select name="position" id="position" class="form-select" required>
                    <option value="1" <?php echo e($customer->position == 1 ? 'selected' : ''); ?>><?php echo app('translator')->get('customer.position_1'); ?></option>
                    <option value="2" <?php echo e($customer->position == 2 ? 'selected' : ''); ?>><?php echo app('translator')->get('customer.position_2'); ?></option>
                    <option value="3" <?php echo e($customer->position == 3 ? 'selected' : ''); ?>><?php echo app('translator')->get('customer.position_3'); ?></option>
                    <option value="4" <?php echo e($customer->position == 4 ? 'selected' : ''); ?>><?php echo app('translator')->get('customer.position_4'); ?></option>
                    <option value="5" <?php echo e($customer->position == 5 ? 'selected' : ''); ?>><?php echo app('translator')->get('customer.position_5'); ?></option>
                </select>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label"><?php echo app('translator')->get('customer.new_password'); ?></label>
                <input type="password" name="password" id="password" class="form-control">
            </div>
            <div class="mb-3">
                <label for="password_confirmation" class="form-label"><?php echo app('translator')->get('customer.confirm_password'); ?></label>
                <input type="password" name="password_confirmation" id="password_confirmation" class="form-control">
            </div>
            <button type="submit" class="btn btn-success"><?php echo app('translator')->get('customer.update_info'); ?></button>
            <a href="<?php echo e(route('customer.dashboard')); ?>" class="btn btn-secondary"><?php echo app('translator')->get('customer.cancel'); ?></a>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/a123/Desktop/npa/resources/views/customer/edit-customer.blade.php ENDPATH**/ ?>