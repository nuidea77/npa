<header id="header" class="navbar navbar-expand-lg navbar-bordered bg-white  ">
    <div class="container">
      <nav class="js-mega-menu navbar-nav-wrap">
        <!-- Logo -->


        <!-- End Logo -->

        <!-- Secondary Content -->
        <div class="navbar-nav-wrap-secondary-content">
          <!-- Navbar -->
             <?php
        $currentLocale = app()->getLocale();
        $newLocale = $currentLocale === 'en' ? 'mn' : 'en';
        ?>
        <a class="btn   fw-semibold   mx-3"
           href="/set-locale/<?php echo $newLocale; ?>">
          <?php echo strtoupper($newLocale); ?>
        </a>
          <ul class="navbar-nav">
            <li class="nav-item">

              <!-- Account -->
              <?php if(auth()->guard('customer')->check()): ?>
                <div class="dropdown">
                  <a class="navbar-dropdown-account-wrapper" href="javascript:;" id="accountNavbarDropdown" data-bs-toggle="dropdown" aria-expanded="false" data-bs-auto-close="outside" data-bs-dropdown-animation>
                    <div class="avatar avatar-sm avatar-circle">
                      <img class="avatar-img" src="<?php echo e(asset('storage/' . Auth::guard('customer')->user()->avatar)); ?>" alt="Image" onerror="this.onerror=null;this.src='<?php echo e(asset('assets/img/user.png')); ?>';">
                      <span class="avatar-status avatar-sm-status avatar-status-success"></span>
                    </div>
                  </a>

                  <div class="dropdown-menu dropdown-menu-end navbar-dropdown-menu navbar-dropdown-menu-borderless navbar-dropdown-account" aria-labelledby="accountNavbarDropdown" style="width: 16rem;">
                    <div class="dropdown-item-text">
                      <div class="d-flex align-items-center">

                        <div class="flex-grow-1 ms-3">
                          <h5 class="mb-0"><?php echo e(Auth::guard('customer')->user()->firstname); ?> <?php echo e(Auth::guard('customer')->user()->lastname); ?></h5>
                          <p class="card-text text-body"><?php echo e(Auth::guard('customer')->user()->email); ?></p>
                        </div>
                      </div>
                    </div>

                    <div class="dropdown-divider"></div>

                    <a class="dropdown-item" href="<?php echo e(route('customer.dashboard')); ?>"><?php echo app('translator')->get('customer.dashboard'); ?></a>
                    <a class="dropdown-item" href="<?php echo e(route('customer.edit')); ?>"><?php echo app('translator')->get('customer.profile_and_account'); ?></a>

                    <div class="dropdown-divider"></div>

                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                       onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                      <?php echo app('translator')->get('register.logout'); ?>
                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                      <?php echo csrf_field(); ?>
                    </form>
                  </div>
                </div>
              <?php else: ?>
                <a href="<?php echo e(route('customer.signin')); ?>" class="btn btn-primary"><?php echo app('translator')->get('customer.login'); ?></a>
              <?php endif; ?>
              <!-- End Account -->
            </li>
          </ul>
          <!-- End Navbar -->
        </div>
        <!-- End Secondary Content -->

        <!-- Toggler -->

        <!-- Collapse -->
        <div class="collapse navbar-collapse" id="navbarContainerNavDropdown">


        </div>
        <!-- End Collapse -->
      </nav>
    </div>
</header>
<?php /**PATH /Users/a123/Desktop/npa/resources/views/customer/layout/header.blade.php ENDPATH**/ ?>