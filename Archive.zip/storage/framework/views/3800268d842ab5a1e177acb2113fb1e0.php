<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <h2 class="mb-4">Мэдэгдлүүд</h2>

    <div class="list-group shadow-sm rounded">
        <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="list-group-item list-group-item-action d-flex flex-column <?php echo e($notification->read_at ? 'bg-white' : 'bg-light'); ?> rounded mb-2 border">
                <div class="d-flex w-100 justify-content-between align-items-center mb-1">
                    <h6 class="mb-0"><?php echo e($notification->data['title'] ?? 'Мэдэгдэл'); ?></h6>
                    <small class="text-muted"><?php echo e($notification->created_at->diffForHumans()); ?></small>
                </div>
                <p class="mb-0 text-muted"><?php echo e($notification->data['message'] ?? ''); ?></p>
                <a href="<?php echo e($notification->data['url'] ?? '#'); ?>"
                   class="mt-2 btn btn-sm btn-outline-primary align-self-start"
                   style="font-size: 0.85rem;">
                    Шийдвэрлэх / Дэлгэрэнгүй
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="p-3 text-center text-muted border rounded">
                Мэдэгдэл алга
            </div>
        <?php endif; ?>
    </div>

    <div class="mt-3 d-flex justify-content-center">
        <?php echo e($notifications->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .list-group-item:hover {
        background-color: #f8f9fa !important;
        transition: background-color 0.2s ease-in-out;
    }
    .list-group-item a.btn {
        padding: 0.25rem 0.5rem;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/a123/Desktop/npa/resources/views/vendor/voyager/notifications/index.blade.php ENDPATH**/ ?>