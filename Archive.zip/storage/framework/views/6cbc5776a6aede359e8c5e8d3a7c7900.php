<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2 class="text-center"><?php echo e(__('register.welcome', ['name' => $customer->firstname])); ?></h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success mt-3">
            <?php echo e(__('customer.success')); ?>

        </div>
    <?php endif; ?>

    <div class="row justify-content-center mt-4">
        
        <div class="col-lg-4 mb-4">
            <div class="card h-100">
                <div class="card-header text-black fw-bold">
                    <?php echo e(__('register.your_info')); ?>

                </div>
                <div class="card-body">
                    <p><strong><?php echo e(__('customer.firstname')); ?>:</strong> <?php echo e($customer->firstname); ?></p>
                    <p><strong><?php echo e(__('customer.lastname')); ?>:</strong> <?php echo e($customer->lastname); ?></p>
                    <p><strong><?php echo e(__('register.sex')); ?>:</strong>
                        <?php echo e($customer->sex == 1 ? __('customer.male') : __('customer.female')); ?>

                    </p>
                    <p><strong><?php echo e(__('customer.email')); ?>:</strong> <?php echo e($customer->email); ?></p>
                    <p><strong><?php echo e(__('customer.phone')); ?>:</strong> <?php echo e($customer->phone); ?></p>
                    <p><strong><?php echo e(__('customer.position')); ?>:</strong>
                        <?php echo e(__('customer.position_' . $customer->position)); ?>

                    </p>
                    <a href="<?php echo e(route('customer.edit')); ?>" class="btn btn-primary mt-3">
                        <?php echo e(__('customer.edit_info')); ?>

                    </a>
                </div>
            </div>
        </div>

        
        <div class="col-lg-4 mb-4">
            <div class="card h-100">
                <div class="card-header text-black fw-bold">
                    <?php echo e(__('customer.stamp_history')); ?>

                </div>
                <div class="card-body">
                    <?php if($stampHistory && $stampHistory->count() > 0): ?>
                        <ul class="list-group">
                            <?php $__currentLoopData = $stampHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="list-group-item d-flex align-items-center">
                                    <img src="<?php echo e(asset('storage/' . $history->stamp->icon)); ?>"
                                         alt="<?php echo e($history->stamp->name); ?>"
                                         style="max-width: 70px; height: auto; margin-right: 15px;">
                                    <div>
                                        <p class="mb-1"><strong><?php echo e(__('customer.stamp_name')); ?>:</strong> <?php echo e($history->stamp->name); ?></p>
                                        <p class="mb-0"><strong><?php echo e(__('customer.stamp_date')); ?>:</strong> <?php echo e($history->stamp->created_at->format('Y-m')); ?></p>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php else: ?>
                        <p><?php echo e(__('customer.no_stamp_history')); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-lg-4 mb-4">
            <div class="card h-100 ">
                <div class="card-header text-black fw-bold">
                    <?php echo e(__('customer.form_title')); ?>

                </div>
                <div class="card-body">
                    <p><?php echo e(__('customer.form_desc')); ?></p>
                    <a href=" " class="btn btn-primary">
                        <?php echo e(__('customer.form_button')); ?>

                    </a>
                </div>
            </div>
        </div>

    </div>
    <div class="row justify-content-center mt-4">
        <div class="col-lg-12 mb-4">
            <div class="card h-100">
                <div class="card-header text-black fw-bold">
                    <?php echo e(__('customer.lesson_list')); ?>

                </div>
                <div class="card-body">

    <?php if($lessons->count() > 0): ?>
        <div class="list-group">
            <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('customer.lesson.view', $lesson->id)); ?>" class="list-group-item list-group-item-action">
                    <div class="d-flex w-100 justify-content-between align-items-center">
                        <h5 class="mb-1"><?php echo e($lesson->title); ?></h5>
                        <small>
                            <?php if($lesson->started_at): ?>
                                <?php echo e(__('customer.started_date')); ?>: <?php echo e(\Carbon\Carbon::parse($lesson->started_at)->format('Y-m-d')); ?>

                            <?php endif; ?>
                        </small>
                    </div>
                    <p class="mb-1 text-truncate" style="max-width: 600px;"><?php echo strip_tags(Str::limit($lesson->body, 100)); ?></p>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <p><?php echo e(__('customer.no_lesson')); ?></p>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/a123/Desktop/npa/resources/views/customer/dashboard.blade.php ENDPATH**/ ?>