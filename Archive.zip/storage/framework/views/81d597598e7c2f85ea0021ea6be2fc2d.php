 

<?php $__env->startSection('content'); ?>
 <div class="container max-width-1920 py-5" data-aos="zoom-in">
    <div class="row py-5">
            <div class="col-lg-12">
               <a href="<?php echo e(url()->previous()); ?>" class="float-start text-black program-date text-decoration-none">
    <i class="bi bi-chevron-left"></i> <?php echo app('translator')->get('texts.back'); ?>
</a>
                <h1 class="text-center fw-bold program-title"><?php echo app('translator')->get('texts.submit-comment'); ?></h1>
            </div>
        </div>
    <div class="row">

      <div class="col-lg-12">
        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>



        <form action="<?php echo e(route('feedback.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-lg-6">
                    <div class="mb-3">
    <label for="type" class="form-label"><?php echo app('translator')->get('texts.type'); ?></label>
    <select name="type" id="type" class="form-select" required>
        <option value=""><?php echo app('translator')->get('texts.choose'); ?></option>
        <option value="1" <?php if(old('type') == '1'): ?> selected <?php endif; ?>>Санал хүсэлт</option>
        <option value="2" <?php if(old('type') == '2'): ?> selected <?php endif; ?>>Талархал</option>
        <option value="3" <?php if(old('type') == '3'): ?> selected <?php endif; ?>>Гомдол</option>
    </select>
</div>
                </div>
                <div class="col-lg-6">
                    <div class="mb-3">
    <label for="subtitle" class="form-label"><?php echo app('translator')->get('texts.subtitle'); ?></label>
    <select name="subtitle" id="subtitle" class="form-select" required>
        <option value=""><?php echo app('translator')->get('texts.choose'); ?></option>
        <option value="1" <?php if(old('subtitle') == '1'): ?> selected <?php endif; ?>>Сайн дурын ажил</option>
        <option value="2" <?php if(old('subtitle') == '2'): ?> selected <?php endif; ?>>Ажлын зар</option>
        <option value="3" <?php if(old('subtitle') == '3'): ?> selected <?php endif; ?>>Бусад</option>
    </select>
</div>
                </div>
                <div class="col-lg-6">
                    <label for="email" class="form-label required-field"><?php echo app('translator')->get('texts.email'); ?></label>
                    <input type="email" class="form-control" id="email" name="email" required placeholder="<?php echo app('translator')->get('texts.email-placeholder'); ?>">
                </div>
                <div class="col-lg-6">
                    <label for="phone" class="form-label required-field"><?php echo app('translator')->get('texts.number'); ?></label>
                    <input type="number" class="form-control" id="phone" name="phone" placeholder="<?php echo app('translator')->get('texts.number-placeholder'); ?>">
                </div>
            </div>
            <div class="row py-3">
                <div class="col-lg-12">
                    <label for="message" class="form-label required-field"><?php echo app('translator')->get('texts.comment'); ?></label>
                    <textarea class="form-control" id="comment" name="comment" rows="4" placeholder="<?php echo app('translator')->get('texts.comment-placeholder'); ?>"></textarea>
                </div>
                <div class="col-lg-12 align-content-center py-3">
                    <button type="submit" class="btn btn-primary"><?php echo app('translator')->get('texts.submit'); ?></button>
                </div>
            </div>
        </form>

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/a123/Desktop/npa/resources/views/customer/form.blade.php ENDPATH**/ ?>