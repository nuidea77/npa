<div class="body-wrapper-inner">
    <?php echo $__env->yieldContent('content'); ?>
</div>
<?php /**PATH /Users/a123/Desktop/npa/resources/views/customer/layout/home.blade.php ENDPATH**/ ?>