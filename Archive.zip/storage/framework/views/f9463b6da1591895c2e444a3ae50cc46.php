<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <h2>Тамга засах</h2>

    <form action="<?php echo e(route('stamp_add.update', [$stampHistory->customer_id, $stampHistory->stamp_id])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        
        <div class="mb-3">
            <label for="customer_id" class="form-label">Хэрэглэгч</label>
            <select name="customer_id[]" class="form-select select2" multiple required>
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($customer->id); ?>"
                        <?php echo e(in_array($customer->id, [$stampHistory->customer_id]) ? 'selected' : ''); ?>>
                        <?php echo e($customer->firstname); ?> <?php echo e($customer->lastname); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        
        <div class="mb-3">
            <label for="stamp_id" class="form-label">Тамга</label>
            <select name="stamp_id[]" class="form-select select2" multiple required>
                <?php $__currentLoopData = $stamps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stamp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($stamp->id); ?>"
                        <?php echo e(in_array($stamp->id, [$stampHistory->stamp_id]) ? 'selected' : ''); ?>>
                        <?php echo e($stamp->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        
        <div class="mb-3">
            <label for="created_at" class="form-label">Огноо</label>
            <input type="date" name="created_at" class="form-control"
                   value="<?php echo e(optional($stampHistory->created_at)->format('Y-m-d')); ?>">
        </div>

        <button type="submit" class="btn btn-success">Хадгалах</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script>
    $(document).ready(function () {
        $('.select2').select2({
            placeholder: "Сонгох...",
            allowClear: true,
            width: '100%'
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/a123/Desktop/npa/resources/views/Admin/stamp_add_edit.blade.php ENDPATH**/ ?>