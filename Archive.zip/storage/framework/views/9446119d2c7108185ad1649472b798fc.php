<?php
    use Carbon\Carbon;
    $now = Carbon::now();
    $isBeforeStart = $now->lt($program->start_date);
    $isAfterEnd = $now->gt($program->end_date);
?>

<div class="container py-5">


    <?php if($isBeforeStart): ?>
        <div class="alert col-lg-4 m-auto alert-warning text-center">
            📅 Бүртгэл <?php echo e($program->start_date->format('Y-m-d')); ?>-нд эхэлнэ.
        </div>
    <?php elseif($isAfterEnd): ?>
        <div class="alert col-lg-4 m-auto alert-danger text-center">
            ❌ Бүртгэл дууссан байна.
        </div>
    <?php endif; ?>

    <?php if($program->require_login && !auth('customer')->check()): ?>
        <div class="alert col-lg-4 m-auto alert-info text-center">
            🔒 Та бүртгүүлэхийн тулд <a href="<?php echo e(route('customer.login')); ?>">нэвтэрнэ үү</a>.
        </div>
    <?php elseif(!$isAfterEnd && !$isBeforeStart): ?>
        <form action="<?php echo e(route('programs.register', $program->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="program_id" value="<?php echo e($program->id); ?>">

            <div class="row g-3 py-4">
                <?php if(auth()->guard('customer')->guest()): ?>
                    <div class="col-md-3">
                        <label class="form-label"><?php echo e(__('register.last_name')); ?></label>
                        <input type="text" name="lastname" class="form-control" placeholder="<?php echo e(__('register.enter_last_name')); ?>" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label"><?php echo e(__('register.first_name')); ?></label>
                        <input type="text" name="firstname" class="form-control" placeholder="<?php echo e(__('register.enter_first_name')); ?>" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label"><?php echo e(__('register.sex')); ?></label>
                        <select name="sex" class="form-select" required>
                            <option value=""><?php echo e(__('register.select_sex')); ?></option>
                            <option value="1"><?php echo e(__('register.male')); ?></option>
                            <option value="2"><?php echo e(__('register.female')); ?></option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label"><?php echo e(__('register.email')); ?></label>
                        <input type="email" name="email" class="form-control" placeholder="<?php echo e(__('register.enter_email')); ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label"><?php echo e(__('register.phone')); ?></label>
                        <input type="text" name="phone" class="form-control" placeholder="<?php echo e(__('register.enter_phone')); ?>" required>
                    </div>


                <div class="col-md-4">
                    <label class="form-label"><?php echo e(__('register.protected_area')); ?></label>
                    <select name="hz" class="form-select" required>
                        <option value=""><?php echo e(__('register.select_protected_area')); ?></option>
                        <option value="tarvagatai_nuru"><?php echo e(__('register.tarvagatai_nuru')); ?></option>
                        <option value="orkhon_khondii"><?php echo e(__('register.orkhon_khondii')); ?></option>
                        <option value="munkhkhairkhan"><?php echo e(__('register.munkhkhairkhan')); ?></option>
                        <option value="ikh_bogd_uul"><?php echo e(__('register.ikh_bogd_uul')); ?></option>
                        <option value="myangan_ugalzat"><?php echo e(__('register.myangan_ugalzat')); ?></option>
                        <option value="nomrog"><?php echo e(__('register.nomrog')); ?></option>
                        <option value="khar_us_nuur"><?php echo e(__('register.khar_us_nuur')); ?></option>
                        <option value="achit_nuur"><?php echo e(__('register.achit_nuur')); ?></option>
                        <option value="otgontenger"><?php echo e(__('register.otgontenger')); ?></option>
                        <option value="bogdkhan_uul"><?php echo e(__('register.bogdkhan_uul')); ?></option>
                        <option value="ulaan_taiga"><?php echo e(__('register.ulaan_taiga')); ?></option>
                        <option value="dornod_mongol"><?php echo e(__('register.dornod_mongol')); ?></option>
                    </select>
                </div>

                <div class="col-md-4">
                    <label class="form-label"><?php echo e(__('register.position')); ?></label>
                    <select name="position" class="form-select" required>
                        <option value=""><?php echo e(__('register.select_position')); ?></option>
                        <option value="leader"><?php echo e(__('register.leader')); ?></option>
                        <option value="senior_expert"><?php echo e(__('register.senior_expert')); ?></option>
                        <option value="expert"><?php echo e(__('register.expert')); ?></option>
                        <option value="nature_guardian"><?php echo e(__('register.nature_guardian')); ?></option>
                        <option value="assistant_nature_guardian"><?php echo e(__('register.assistant_nature_guardian')); ?></option>
                    </select>
                </div>
                 <?php elseif(auth()->guard('customer')->check()): ?>
                    <input type="hidden" name="customer_id" value="<?php echo e(auth('customer')->user()->id); ?>">
                    <input type="hidden" name="lastname" value="<?php echo e(auth('customer')->user()->lastname); ?>">
                    <input type="hidden" name="firstname" value="<?php echo e(auth('customer')->user()->firstname); ?>">
                    <input type="hidden" name="email" value="<?php echo e(auth('customer')->user()->email); ?>">
                    <input type="hidden" name="phone" value="<?php echo e(auth('customer')->user()->phone); ?>">
                    <input type="hidden" name="hz" value="<?php echo e(auth('customer')->user()->hz); ?>">
                    <input type="hidden" name="position" value="<?php echo e(auth('customer')->user()->position); ?>">
                <?php endif; ?>

                <div class="col-12">
                    <label class="form-label"><?php echo app('translator')->get('texts.answer_optional'); ?></label>
                    <textarea name="answer" class="form-control" placeholder="<?php echo app('translator')->get('texts.answer_hint'); ?>" rows="4"></textarea>
                </div>



                <div class="col-12 text-center pt-4">
                    <button type="submit" class="btn btn-primary px-5"
                        <?php if($isBeforeStart || $isAfterEnd): ?> disabled <?php endif; ?>>
                        <?php echo e(__('register.register')); ?>

                    </button>
                </div>
            </div>
        </form>
    <?php endif; ?>

</div>
<?php /**PATH /Users/a123/Desktop/npa/resources/views/program/_form.blade.php ENDPATH**/ ?>