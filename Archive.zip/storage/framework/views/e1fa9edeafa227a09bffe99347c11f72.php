<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <h2 class="mb-4"> <?php echo app('translator')->get('texts.stamp-history'); ?></h2>
    <a href="<?php echo e(route('stamp_add.create')); ?>" class="btn btn-primary mb-3"> <?php echo app('translator')->get('texts.stamp-add'); ?></a>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Хэрэглэгч</th>
                <th>Тамга</th>
                <th>Огноо</th>
                <th> Үйлдэл</th>
            </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $stampHistories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e($history->customer->firstname ?? 'N/A'); ?> <?php echo e($history->customer->lastname ?? ''); ?></td>
    <td><?php echo e($history->stamp->name ?? 'N/A'); ?></td>
    <td><?php echo e($history->created_at ? $history->created_at->format('Y-m-d') : 'N/A'); ?></td>

    <td class="d-flex gap-2">
        <!-- Edit товч -->
        <a href="<?php echo e(route('stamp_add.edit', [$history->customer_id, $history->stamp_id])); ?>" class="btn btn-sm btn-primary">Засах</a>

        <!-- Delete товч -->
        <form action="<?php echo e(route('stamp_add.destroy', [$history->customer_id, $history->stamp_id])); ?>" method="POST" onsubmit="return confirm('Устгах уу?')">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button class="btn btn-sm btn-danger">Устгах</button>
        </form>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/a123/Desktop/npa/resources/views/Admin/stamp_add.blade.php ENDPATH**/ ?>