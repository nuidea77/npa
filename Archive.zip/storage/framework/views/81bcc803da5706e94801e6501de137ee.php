<?php $__env->startSection('head'); ?>
    <!-- Select2 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto py-6 px-4">
    <div class="bg-white rounded-2xl shadow p-6 max-w-2xl mx-auto">
        <h2 class="text-2xl font-semibold mb-4 text-gray-800"> Хэрэглэгчдэд тамга оноох</h2>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('stamp_add.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <!-- Хэрэглэгчид -->
            <div class="mb-4">
                <label for="customer_id" class="form-label font-semibold"> Хэрэглэгчид</label>
                <select name="customer_id[]" id="customer_id" class="form-select" multiple required>
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($customer->id); ?>"><?php echo e($customer->firstname); ?> <?php echo e($customer->lastname); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <!-- Тамганууд -->
            <div class="mb-4">
                <label for="stamp_id" class="form-label font-semibold"> Тамганууд</label>
                <select name="stamp_id[]" id="stamp_id" class="form-select" multiple required>
                    <?php $__currentLoopData = $stamps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stamp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($stamp->id); ?>"><?php echo e($stamp->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <!-- Огноо сонгох -->
<div class="mb-4">
    <label for="created_at" class="form-label font-semibold">Огноо сонгох</label>
    <input type="date" id="created_at" name="created_at" class="form-control" required>
</div>


            <!-- Submit button -->
            <div class="text-end">
                <button type="submit" class="btn btn-primary px-4 py-2 rounded-xl">
                    Хадгалах
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <!-- jQuery + Select2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <script>
        $(document).ready(function() {
            $('#customer_id').select2({
                placeholder: "Хэрэглэгч сонгох",
                allowClear: true,
                width: '100%'
            });

            $('#stamp_id').select2({
                placeholder: "Тамга сонгох",
                allowClear: true,
                width: '100%'
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/a123/Desktop/npa/resources/views/Admin/stamp_add_create.blade.php ENDPATH**/ ?>