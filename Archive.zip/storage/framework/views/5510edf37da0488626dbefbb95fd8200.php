<?php $__env->startSection('content'); ?>


<div class="container-fluid  ">
    <div class="row">
        <div class="col-lg-12" style="background-image: url(assets/img/about-cover.jpg); background-size: cover; background-position: center; height: 650px;">
        </div>
      </div>
    <div class="row pb-3">
        <div class="col-md-12 pt-5 ">
             <a href="<?php echo e(url()->previous()); ?>" class="float-start program-date text-decoration-none">
    <i class="bi bi-chevron-left"></i> <?php echo app('translator')->get('texts.back'); ?>
</a>
            <h4 class="text-center  text-uppercase fw-semibold"><?php echo app('translator')->get('texts.protected-areas'); ?></h4>
        </div>
    </div>
    <div class="row">

        <div class="col-md-12">
            <div class="d-flex justify-content-center">
                <form method="GET" action="<?php echo e(route('place.index')); ?>">
                    <div class="d-flex justify-content-end">
                        <!-- Province (City) Filter -->
                        <div class="input-group mx-2">
                            <select name="city_id" class="form-select" onchange="this.form.submit()" aria-label="Filter by Province">
                                <option value="" selected disabled hidden><?php echo app('translator')->get('texts.by-province'); ?></option>
                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($city->id); ?>" <?php echo e(request('city_id') == $city->id ? 'selected' : ''); ?>>
                                        <?php echo e($city->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <!-- Place Name Filter -->
                        <div class="input-group">
                            <select name="place_id" class="form-select" onchange="this.form.submit()" aria-label="Filter by Place Name">
                                <option value="" selected disabled hidden><?php echo app('translator')->get('texts.thg-name'); ?></option>
                                <?php $__currentLoopData = $placesOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $placeOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($placeOption->id); ?>" <?php echo e(request('place_id') == $placeOption->id ? 'selected' : ''); ?>>
                                        <?php echo e($placeOption->title); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <!-- Search Button -->
                    </div>
                </form>
            </div>
        </div>
    </div>
    <hr>
</div>

<div class="container-fluid max-width-1920 py-4">
    <div class="row pb-5">
        <!-- Check if places exist -->
        <?php if($places->isEmpty()): ?>
            <div class="col-12">
                <p class="text-center">Хайлтанд тохирох үр дүн олдсонгүй.</p>
            </div>
        <?php else: ?>
            <?php $__currentLoopData = $places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 col-lg-4 mb-4" data-aos="fade-right">
            <div class="card program-card">
                <img src="<?php echo e(Voyager::image($data->f_image)); ?>" style="height: 350px;" alt="Хөвсгөл нуур">
                <div class="card-body bg-primary">
                    <h5 class="card-title"><?php echo e($data->title); ?></h5>
                    <p class="card-text card-description text-white "><?php echo e($data->hz_info); ?></p>
                    <a href="/spa/<?php echo e($data->id); ?>" class="btn btn-hover-animation-switch  card-button fw-semibold text-white p-0 ">
                        <span>
                        <span class="btn-text"><?php echo app('translator')->get('texts.read-more'); ?></span>
                        <span class="btn-icon"> <i class="bi bi-arrow-right"></i></span>
                        <span class="btn-icon"><i class="bi bi-arrow-right"></i></span>
                      </span>
                      </a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>

    <!-- Pagination -->
    <div class="d-flex justify-content-center">
        <?php echo e($places->appends(request()->query())->links()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/a123/Desktop/npa/resources/views/place/index.blade.php ENDPATH**/ ?>