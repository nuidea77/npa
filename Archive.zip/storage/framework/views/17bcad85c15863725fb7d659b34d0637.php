<nav class="navbar navbar-default navbar-fixed-top navbar-top">
    <div class="container-fluid">
        <div class="navbar-header">
            <button class="hamburger btn-link">
                <span class="hamburger-inner"></span>
            </button>
            <?php $__env->startSection('breadcrumbs'); ?>
            <ol class="breadcrumb hidden-xs">
                <?php
                $segments = array_filter(explode('/', str_replace(route('voyager.dashboard'), '', Request::url())));
                $url = route('voyager.dashboard');
                ?>
                <?php if(count($segments) == 0): ?>
                    <li class="active"><i class="voyager-boat"></i> <?php echo e(__('voyager::generic.dashboard')); ?></li>
                <?php else: ?>
                    <li class="active">
                        <a href="<?php echo e(route('voyager.dashboard')); ?>"><i class="voyager-boat"></i> <?php echo e(__('voyager::generic.dashboard')); ?></a>
                    </li>
                    <?php $__currentLoopData = $segments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $segment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $url .= '/'.$segment;
                        ?>
                        <?php if($loop->last): ?>
                            <li><?php echo e(ucfirst(urldecode($segment))); ?></li>
                        <?php else: ?>
                            <li>
                                <a href="<?php echo e($url); ?>"><?php echo e(ucfirst(urldecode($segment))); ?></a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </ol>
            <?php echo $__env->yieldSection(); ?>
        </div>
        <ul class="nav navbar-nav <?php if(__('voyager::generic.is_rtl') == 'true'): ?> navbar-left <?php else: ?> navbar-right <?php endif; ?>">

<li class="nav-item dropdown">
    <a href="#" class="nav-link dropdown-toggle position-relative" data-toggle="dropdown">
        <i class="voyager-bell"></i>
        <?php $unreadCount = auth()->user()->unreadNotifications->count(); ?>
        <?php if($unreadCount > 0): ?>
            <span class="badge badge-danger position-absolute top-0 start-100 translate-middle">
                <?php echo e($unreadCount); ?>

            </span>
        <?php endif; ?>
    </a>

    <div class="dropdown-menu dropdown-menu-right shadow-lg p-0" style="min-width: 350px;">
        
        <div class="bg-primary text-white rounded-top d-flex align-items-center justify-content-between px-3 py-2">
            <strong style="font-size: 1rem;">Мэдэгдлүүд</strong>
        </div>

        
        <div class="list-group list-group-flush" style="max-height: 350px; overflow-y: auto; padding: 5px;">
            <?php $__empty_1 = true; $__currentLoopData = auth()->user()->unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a href="<?php echo e($notification->data['url'] ?? '#'); ?>"
                   class="list-group-item list-group-item-action notification-link d-flex flex-column mb-2 <?php echo e($notification->read_at ? 'bg-white text-dark' : 'bg-primary text-white'); ?>"
                   style="border-radius: 8px; padding: 12px 15px; transition: all 0.2s;"
                   data-id="<?php echo e($notification->id); ?>">
                    <div class="d-flex w-100 justify-content-between align-items-center mb-1">
                        <h6 class="mb-0" style="font-weight: 600; font-size: 0.95rem;"><?php echo e($notification->data['title'] ?? 'Мэдэгдэл'); ?></h6>
                        <small style="font-size: 0.75rem; opacity: 0.7;"><?php echo e($notification->created_at->diffForHumans()); ?></small>
                    </div>
                    <p class="mb-0" style="font-size: 0.85rem; line-height: 1.3; opacity: 0.9;">
                        <?php echo e($notification->data['message'] ?? ''); ?>

                    </p>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="p-3 text-center text-muted border-bottom">
                    Мэдэгдэл алга
                </div>
            <?php endif; ?>
        </div>

        
        <div class="p-2 text-center border-top">
            <a href="<?php echo e(route('voyager.notifications.index')); ?>" class="btn btn-sm btn-outline-light w-100">
                Бүгдийг харах
            </a>
        </div>
    </div>
</li>

<?php $__env->startSection('styles'); ?>
<style>
    .notification-link:hover {
        background-color: #f0f0f0; /* Hover effect */
        transition: background-color 0.2s ease-in-out;
    }
    .badge {
        font-size: 0.65rem;
    }
</style>
<?php $__env->stopSection(); ?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    $('.notification-link').click(function(e){
        e.preventDefault();
        let link = $(this).attr('href');
        let id = $(this).data('id');

        $.post('<?php echo e(route('notifications.read')); ?>', {
            _token: '<?php echo e(csrf_token()); ?>',
            id: id
        }, function(){
            window.location.href = link;
        });
    });
});
</script>






            <li class="dropdown profile">
                <a href="#" class="dropdown-toggle text-right" data-toggle="dropdown" role="button"
                   aria-expanded="false"><img src="<?php echo e($user_avatar); ?>" class="profile-img"> <span
                            class="caret"></span></a>
                <ul class="dropdown-menu dropdown-menu-animated">
                    <li class="profile-img">
                        <img src="<?php echo e($user_avatar); ?>" class="profile-img">
                        <div class="profile-body">
                            <h5><?php echo e(Auth::user()->name); ?></h5>
                            <h6><?php echo e(Auth::user()->email); ?></h6>
                        </div>
                    </li>
                    <li class="divider"></li>
                    <?php $nav_items = config('voyager.dashboard.navbar_items'); ?>
                    <?php if(is_array($nav_items) && !empty($nav_items)): ?>
                    <?php $__currentLoopData = $nav_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li <?php echo isset($item['classes']) && !empty($item['classes']) ? 'class="'.$item['classes'].'"' : ''; ?>>
                        <?php if(isset($item['route']) && $item['route'] == 'voyager.logout'): ?>
                        <form action="<?php echo e(route('voyager.logout')); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <button type="submit" class="btn btn-danger btn-block">
                                <?php if(isset($item['icon_class']) && !empty($item['icon_class'])): ?>
                                <i class="<?php echo $item['icon_class']; ?>"></i>
                                <?php endif; ?>
                                <?php echo e(__($name)); ?>

                            </button>
                        </form>
                        <?php else: ?>
                        <a href="<?php echo e(isset($item['route']) && Route::has($item['route']) ? route($item['route']) : (isset($item['route']) ? $item['route'] : '#')); ?>" <?php echo isset($item['target_blank']) && $item['target_blank'] ? 'target="_blank"' : ''; ?>>
                            <?php if(isset($item['icon_class']) && !empty($item['icon_class'])): ?>
                            <i class="<?php echo $item['icon_class']; ?>"></i>
                            <?php endif; ?>
                            <?php echo e(__($name)); ?>

                        </a>
                        <?php endif; ?>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </ul>
            </li>

        </ul>
    </div>
</nav>
<?php /**PATH /Users/a123/Desktop/npa/vendor/tcg/voyager/resources/views/dashboard/navbar.blade.php ENDPATH**/ ?>