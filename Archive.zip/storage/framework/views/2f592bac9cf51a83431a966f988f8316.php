<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Sign Up | NPA Website</title>

  <link rel="shortcut icon" href="<?php echo e(asset('assets/img/favicon.png')); ?>">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo e(asset('assets/admin/assets/css/vendor.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/admin/assets/css/theme.min.css')); ?>">
</head>

<body class="d-flex align-items-center min-h-100">



<main id="content" role="main" class="main pt-0">
  <div class="container-fluid px-3">
    <div class="row">
      <div class="col-lg-8 d-none d-lg-flex justify-content-center align-items-center  bg-light" style="background: url('<?php echo e(asset('assets/img/about-cover.jpg')); ?>') no-repeat center center; background-size: cover;">


      </div>

      <div class="col-lg-4 d-flex justify-content-center align-items-center min-vh-lg-100">
        
<div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header bg-success text-white">
        <h5 class="modal-title" id="successModalLabel">Амжилттай</h5>
      </div>
      <div class="modal-body text-center">
        <?php echo e($success_message ?? ''); ?>

      </div>
      <div class="modal-footer">
        <a href="/" class="btn btn-primary">Ойлголоо</a>
      </div>
    </div>
  </div>
</div>


<?php if(!empty($success_message)): ?>
<script>
    window.addEventListener('DOMContentLoaded', function () {
        var successModal = new bootstrap.Modal(document.getElementById('successModal'));
        successModal.show();
    });
</script>
<?php endif; ?>

        <div class="w-100 " style="max-width: 25rem;">


            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

          
          <form action="<?php echo e(route('customer.register.submit')); ?>" method="POST" enctype="multipart/form-data">
            <div class="row">
              <?php echo csrf_field(); ?>
              <div class="mb-3 col-lg-6 col-md-6">
                <label for="firstname" class="form-label"><?php echo app('translator')->get('register.first_name'); ?></label>
                <input type="text" name="firstname" id="firstname" class="form-control" placeholder="<?php echo app('translator')->get('register.enter_first_name'); ?>" value="<?php echo e(old('firstname')); ?>" required>
                <div id="firstnameError" class="invalid-feedback">
                  <?php echo app('translator')->get('register.error_first_name_mongolian'); ?>
                </div>
              </div>

              <div class="mb-3 col-lg-6 col-md-6">
                <label for="lastname" class="form-label"><?php echo app('translator')->get('register.last_name'); ?></label>
                <input type="text" name="lastname" id="lastname" class="form-control" placeholder="<?php echo app('translator')->get('register.enter_last_name'); ?>" value="<?php echo e(old('lastname')); ?>" required>
                <div id="lastnameError" class="invalid-feedback">
                  <?php echo app('translator')->get('register.error_last_name_mongolian'); ?>
                </div>
              </div>



              <div class="mb-3 col-lg-6 col-md-6">
                  <label for="email" class="form-label"><?php echo app('translator')->get('register.email'); ?></label>
                  <input type="email" name="email" id="email" class="form-control" placeholder="<?php echo app('translator')->get('register.enter_email'); ?>" value="<?php echo e(old('email')); ?>" required>
               <small id="email-error" class="text-danger"></small>
                </div>
              <div class="mb-3 col-lg-6 col-md-6">
                  <label for="phone" class="form-label"><?php echo app('translator')->get('register.phone'); ?></label>
                  <input type="text" name="phone" id="phone" class="form-control" placeholder="<?php echo app('translator')->get('register.enter_phone'); ?>" value="<?php echo e(old('phone')); ?>" required>
              <small id="phone-error" class="text-danger"></small>
                </div>
              <div class="mb-3 col-lg-6 col-md-6">
                <label for="sex" class="form-label"><?php echo app('translator')->get('register.sex'); ?></label>
                <select name="sex" id="sex" class="form-select" required>
                    <option value="" disabled selected><?php echo app('translator')->get('register.select_sex'); ?></option>
                    <option value="1"><?php echo app('translator')->get('register.male'); ?></option>
                    <option value="2"><?php echo app('translator')->get('register.female'); ?></option>
                </select>
            </div>

              <div class="mb-3 col-lg-6 col-md-6">
                  <label for="position" class="form-label"><?php echo app('translator')->get('register.position'); ?></label>
                  <select name="position" id="position" class="form-select" required>
                      <option value="" disabled selected><?php echo app('translator')->get('register.select_position'); ?></option>
                      <option value="1"><?php echo app('translator')->get('register.leader'); ?></option>
                      <option value="2"><?php echo app('translator')->get('register.senior_expert'); ?></option>
                      <option value="3"><?php echo app('translator')->get('register.expert'); ?></option>
                      <option value="4"><?php echo app('translator')->get('register.nature_guardian'); ?></option>
                      <option value="5"><?php echo app('translator')->get('register.assistant_nature_guardian'); ?></option>
                  </select>
              </div>
              <div class="mb-3 col-lg-12 col-md-12">
                <label for="hz" class="form-label"><?php echo app('translator')->get('register.protected_area'); ?></label>
                <select name="hz" id="hz" class="form-select" required>
                    <option value="" disabled selected><?php echo app('translator')->get('register.select_protected_area'); ?></option>
                    <option value="1"><?php echo app('translator')->get('register.tarvagatai_nuru'); ?></option>
                    <option value="2"><?php echo app('translator')->get('register.orkhon_khondii'); ?></option>
                    <option value="3"><?php echo app('translator')->get('register.munkhkhairkhan'); ?></option>
                    <option value="4"><?php echo app('translator')->get('register.ikh_bogd_uul'); ?></option>
                    <option value="5"><?php echo app('translator')->get('register.myangan_ugalzat'); ?></option>
                    <option value="6"><?php echo app('translator')->get('register.nomrog'); ?></option>
                    <option value="7"><?php echo app('translator')->get('register.khar_us_nuur'); ?></option>
                    <option value="8"><?php echo app('translator')->get('register.achit_nuur'); ?></option>
                    <option value="9"><?php echo app('translator')->get('register.otgontenger'); ?></option>
                    <option value="10"><?php echo app('translator')->get('register.bogdkhan_uul'); ?></option>
                    <option value="11"><?php echo app('translator')->get('register.ulaan_taiga'); ?></option>
                    <option value="12"><?php echo app('translator')->get('register.dornod_mongol'); ?></option>
                </select>
            </div>
              
              <div class="mb-3 col-lg-12 col-md-6">
                <label for="password" class="form-label"><?php echo app('translator')->get('register.password'); ?></label>
                <input type="password" name="password" id="password" class="form-control" placeholder="<?php echo app('translator')->get('register.enter_password'); ?>" required>
                <div id="passwordLengthError" class="invalid-feedback"><?php echo app('translator')->get('register.error_password_min'); ?></div>
            </div>

            
            <div class="mb-3 col-lg-12 col-md-6">
                <label for="password_confirmation" class="form-label"><?php echo app('translator')->get('register.confirm_password'); ?></label>
                <input type="password" name="password_confirmation" id="password_confirmation" class="form-control" placeholder="<?php echo app('translator')->get('register.confirm_password'); ?>" required>
                <div id="passwordMismatchError" class="invalid-feedback"><?php echo app('translator')->get('register.error_password_confirmation'); ?></div>
            </div>

            
            <button type="submit" class="btn btn-primary "><?php echo app('translator')->get('register.register'); ?></button>
        </div>
        </form>

      </div>
    </div>
  </div>
</div>
</main>

<script src="<?php echo e(asset('assets/admin/assets/js/vendor.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/assets/js/theme.min.js')); ?>"></script>


<script>
document.addEventListener('DOMContentLoaded', function () {
  const mongolianRegex = /^[А-Яа-яӨөҮүЁё\s]+$/;
  const firstname = document.getElementById('firstname');
  const lastname = document.getElementById('lastname');
  const password = document.getElementById('password');
  const passwordConfirmation = document.getElementById('password_confirmation');

  const passwordLengthError = document.getElementById('passwordLengthError');
  const passwordMismatchError = document.getElementById('passwordMismatchError');
  const firstnameError = document.getElementById('firstnameError');
  const lastnameError = document.getElementById('lastnameError');

  function validateMongolian(input, error) {
      if (input.value !== '' && !mongolianRegex.test(input.value)) {
          input.classList.add('is-invalid');
          error.style.display = 'block';
      } else {
          input.classList.remove('is-invalid');
          error.style.display = 'none';
      }
  }

  function checkPasswordLength() {
      if (password.value.length > 0 && password.value.length < 8) {
          password.classList.add('is-invalid');
          passwordLengthError.style.display = 'block';
      } else {
          password.classList.remove('is-invalid');
          passwordLengthError.style.display = 'none';
      }
  }

  function checkPasswordMatch() {
      if (password.value !== passwordConfirmation.value) {
          passwordConfirmation.classList.add('is-invalid');
          passwordMismatchError.style.display = 'block';
      } else {
          passwordConfirmation.classList.remove('is-invalid');
          passwordMismatchError.style.display = 'none';
      }
  }

  firstname.addEventListener('input', () => validateMongolian(firstname, firstnameError));
  lastname.addEventListener('input', () => validateMongolian(lastname, lastnameError));
  password.addEventListener('input', checkPasswordLength);
  passwordConfirmation.addEventListener('input', checkPasswordMatch);
});
  document.addEventListener("DOMContentLoaded", function () {

    const emailField = document.getElementById('email');
    const phoneField = document.getElementById('phone');
    const emailError = document.getElementById('email-error');
    const phoneError = document.getElementById('phone-error');

    // Имэйл валидаци
    emailField.addEventListener('input', function () {
      const email = emailField.value.trim();
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

      if (!emailRegex.test(email)) {
        emailError.textContent = 'Имэйл бичиглэл буруу байна. @ болон . ашиглана уу.';
      } else {
        emailError.textContent = '';
      }
    });

    // Утасны дугаар валидаци
    phoneField.addEventListener('input', function () {
      const phone = phoneField.value.trim();
      const phoneRegex = /^\d{8}$/;

      if (!phoneRegex.test(phone)) {
        phoneError.textContent = 'Утасны дугаар 8 оронтой цифр байх ёстой.';
      } else {
        phoneError.textContent = '';
      }
    });



  });

</script>

</body>
</html>
<?php /**PATH /Users/a123/Desktop/npa/resources/views/customer/register.blade.php ENDPATH**/ ?>